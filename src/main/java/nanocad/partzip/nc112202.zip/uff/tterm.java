package nanocad.minimize.uff;

/**
 * tterm.java - MM2-style torsion energy term
 * Copyright (c) 1997,1998 Will Ware, all rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and other materials provided with the distribution.
 * 
 * This software is provided "as is" and any express or implied warranties,
 * including, but not limited to, the implied warranties of merchantability
 * or fitness for any particular purpose are disclaimed. In no event shall
 * Will Ware be liable for any direct, indirect, incidental, special,
 * exemplary, or consequential damages (including, but not limited to,
 * procurement of substitute goods or services; loss of use, data, or
 * profits; or business interruption) however caused and on any theory of
 * liability, whether in contract, strict liability, or tort (including
 * negligence or otherwise) arising in any way out of the use of this
 * software, even if advised of the possibility of such damage.
 */

import java.lang.Math;
import java.util.Vector;
import nanocad.*;

public class tterm extends term
{
  private double vphi;
  private int n;
  private double phi0;
  private final static double convert = Math.PI/180;	// Convert degrees to radians
/**
 * Insert the method's description here.
 * Creation date: (6/19/00 4:09:57 PM)
 */
  public tterm() {}

  public tterm(atom a1, atom a2, atom a3, atom a4) {
	int i;
	boolean found;
	myAtoms = new atom[4];
	myAtoms[0] = a1;
	myAtoms[1] = a2;
	myAtoms[2] = a3;
	myAtoms[3] = a4;
	setCalculationValues();
  }

  protected void buildTerm (Vector v, Vector termList)
	{
	    myGroup = ((atom)v.elementAt(0)).getGroup();
	    if(myGroup.needsToGetTypes()) myGroup.setTypes();
	    int atom1 = ((atom)v.elementAt(0)).getUFFTypeNum();
	    int atom2 = ((atom)v.elementAt(1)).getUFFTypeNum();
	    int atom3 = ((atom)v.elementAt(2)).getUFFTypeNum();
	    int atom4 = ((atom)v.elementAt(3)).getUFFTypeNum();  
	
	    if (atom1 < atom4 && atom2 < atom3)
	    {
		tterm t = new tterm ((atom) v.elementAt(0),
			   (atom) v.elementAt(1),
			   (atom) v.elementAt(2),
			   (atom) v.elementAt(3));

		
	  	if (t.vphi != 0.0)
	    	{
		    termList.addElement(t);
		    //System.out.println("added: " + atom1 + " " + atom2 + " " + atom3 + " " + atom4);
		}
	    }
	    else if (atom2 == atom3 && atom1 < atom4)
	    {
		if ( ((atom)v.elementAt(1)).x[0] >= ((atom)v.elementAt(2)).x[0])
	    	{
	   	    tterm t = new tterm ((atom) v.elementAt(0),
			   (atom) v.elementAt(1),
			   (atom) v.elementAt(2),
			   (atom) v.elementAt(3));
	  	    	if (t.vphi != 0.0)
	    	    {
			termList.addElement(t);
		    	//System.out.println("added: " + atom1 + " " + atom2 + " " + atom3 + " " + atom4);
		    }
	        }
	    }
	    else if (atom2 == atom3 && atom1 == atom4)
	    {
		if ( ((atom)v.elementAt(1)).x[0] >= ((atom)v.elementAt(2)).x[0] )
		{
		    tterm t = new tterm ((atom) v.elementAt(0),
			   (atom) v.elementAt(1),
			   (atom) v.elementAt(2),
			   (atom) v.elementAt(3));
	  	    if (t.vphi != 0.0)
	    	    {
		    	termList.addElement(t);
		    	//System.out.println("added: " + atom1 + " " + atom2 + " " + atom3 + " " + atom4);
		    }
		}
	    }
	}

  public double computePotential(double phi){
	double temp1 = n*phi0;
	double temp2 = n*phi;
	if(temp1 > 1) temp1 = 1;
	if(temp1 < -1) temp1 = -1;
	if(temp2 > 1) temp2 = 1;
	if(temp2 < -1) temp2 = -1;
	return 0.5*vphi*(1-Math.cos(temp1)*Math.cos(temp2));
  }

  public double computePotentialDerivative(double phi){
	double temp1 = n*phi0;
	double temp2 = n*phi;
	if(temp1 > 1) temp1 = 1;
	if(temp1 < -1) temp1 = -1;
	if(temp2 > 1) temp2 = 1;
	if(temp2 < -1) temp2 = -1;
	return 0.5*n*vphi*Math.cos(temp1)*Math.sin(temp2);
  }

  public double computeForces ()
	{
	
	double ab[], bc[], cd[], na[], nd[], nadotna, nddotnd, nadotnd, theta, dedth, dthdab[], dthdbc[], dthdcd[], denominator;
	ab = new double[3]; bc = new double[3]; cd = new double[3]; na = new double[3]; nd = new double[3]; dthdab = new double[3];
	dthdbc = new double[3]; dthdcd = new double[3];

	for (int i = 0; i < 3; i++)
	{
	    ab[i] = myAtoms[1].x[i] - myAtoms[0].x[i];
	    bc[i] = myAtoms[2].x[i] - myAtoms[1].x[i];
	    cd[i] = myAtoms[3].x[i] - myAtoms[2].x[i];	  
	}

	na[0] = ab[1]*bc[2] - ab[2]*bc[1];
	na[1] = ab[2]*bc[0] - ab[0]*bc[2];
	na[2] = ab[0]*bc[1] - ab[1]*bc[0];

	nd[0] = bc[1]*cd[2] - bc[2]*cd[1];
	nd[1] = bc[2]*cd[0] - bc[0]*cd[2];
	nd[2] = bc[0]*cd[1] - bc[1]*cd[0];

	nadotna = na[0]*na[0] + na[1]*na[1] + na[2]*na[2];
	nadotnd = na[0]*nd[0] + na[1]*nd[1] + na[2]*nd[2];
	nddotnd = nd[0]*nd[0] + nd[1]*nd[1] + nd[2]*nd[2];

	if(nadotna <= 0) nadotna = uffMinimizeAlgorythm.TINY;
	if(nddotnd <= 0) nddotnd = uffMinimizeAlgorythm.TINY;

	double jtemp1 = nadotnd / Math.sqrt(nadotna * nddotnd);
	if(jtemp1 < -1) jtemp1 = -1;
	if(jtemp1 > 1) jtemp1 = 1;
	theta = Math.acos(jtemp1);

	dedth = computePotentialDerivative(theta);
	potential = computePotential(theta);

	double jtemp2 = nadotna * nddotnd - nadotnd * nadotnd;
	if(jtemp2 <= 0) jtemp2 = uffMinimizeAlgorythm.TINY;
	denominator = Math.sqrt(jtemp2);

	dthdab[0] = (nd[1]*bc[2] - nd[2]*bc[1] + (na[2]*bc[1] - na[1]*bc[2]) * nadotnd / nadotna) / denominator;
	dthdbc[0] = (nd[2]*ab[1] - nd[1]*ab[2] + na[1]*cd[2] - na[2]*cd[1] + (na[1]*ab[2] - na[2]*ab[1]) * nadotnd / nadotna
		+ (nd[2]*cd[1] - nd[1]*cd[2]) * nadotnd / nddotnd) / denominator;
	dthdcd[0] = (na[2]*bc[1] - na[1]*bc[2] + (nd[1]*bc[2] - nd[2]*bc[1]) * nadotnd / nddotnd) / denominator;

	dthdab[1] = (nd[2]*bc[0] - nd[0]*bc[2] + (na[0]*bc[2] - na[2]*bc[0]) * nadotnd / nadotna) / denominator;
	dthdbc[1] = (nd[0]*ab[2] - nd[2]*ab[0] + na[2]*cd[0] - na[0]*cd[2] + (na[2]*ab[0] - na[0]*ab[2]) * nadotnd / nadotna
		+ (nd[0]*cd[2] - nd[2]*cd[0]) * nadotnd / nddotnd) / denominator;
	dthdcd[1] = (na[0]*bc[2] - na[2]*bc[0] + (nd[2]*bc[0] - nd[0]*bc[2]) * nadotnd / nddotnd) / denominator;

	
	dthdab[2] = (nd[0]*bc[1] - nd[1]*bc[0] + (na[1]*bc[0] - na[0]*bc[1]) * nadotnd / nadotna) / denominator;
	dthdbc[2] = (nd[1]*ab[0] - nd[0]*ab[1] + na[0]*cd[1] - na[1]*cd[0] + (na[0]*ab[1] - na[1]*ab[0]) * nadotnd / nadotna
		+ (nd[1]*cd[0] - nd[0]*cd[1]) * nadotnd / nddotnd) / denominator;
	dthdcd[2] = (na[1]*bc[0] - na[0]*bc[1] + (nd[0]*bc[1] - nd[1]*bc[0]) * nadotnd / nddotnd) / denominator;

	for (int i = 0; i < 3; i++)
	{
	    myAtoms[0].f[i] += dedth * -dthdab[i];
	    myAtoms[1].f[i] += dedth * (dthdab[i] - dthdbc[i]);
	    myAtoms[2].f[i] += dedth * (dthdbc[i] - dthdcd[i]);
	    myAtoms[3].f[i] += dedth * dthdcd[i];
	}
	return myAtoms[0].f[0];
    } 


  protected String repr2()
	{
	  return new String("torsion "+vphi+" "+n);
	}
/**
 * Insert the method's description here.
 * Creation date: (6/15/00 1:40:30 PM)
 */
protected void setCalculationValues() {
	System.out.println("Creating tterm");
	myGroup = myAtoms[0].getGroup();
	if(myGroup.needsToGetTypes()) myGroup.setTypes();
	int atomOneType = myAtoms[0].getUFFTypeNum();
	int atomTwoType = myAtoms[1].getUFFTypeNum();
	int atomThreeType = myAtoms[2].getUFFTypeNum();
	int atomFourType = myAtoms[3].getUFFTypeNum();
	if ((atomOneType < 0) || (atomTwoType < 0) || (atomThreeType < 0) || (atomFourType < 0)) {
		System.out.println("ERROR: No UFF Type for "+myAtoms[0].toString()+", "+myAtoms[1].toString()+", "+myAtoms[2].toString()+", "+myAtoms[3].toString());
		return;
	}

	// Need to determine the group and hybridization of the atoms, so we
	// can determine the form vphi should take.  The following order is important;
	// the first if stmts are exceptions to the more general rules that follow.
	// Order of atoms is 0,3:edge, 1,2: central

	// to determine if either central atom is from group 6
	boolean bfromG6 = false;
	boolean cfromG6 = false;

	// to determine the sp3 params for atoms b,c; easier to do it here than
	// to reproduce it in each sp3 case.
	double Uj = 0.0;
	double Uk = 0.0;
	switch (myAtoms[1].atomicNumber()){
	case 6: Uj = 2.119;
		break;
	case 7: Uj = 0.450;
		break;
	case 8: Uj = 0.018;
		break;
	case 14: Uj = 1.225;
		break;
	case 15: Uj = 2.400;
		break;
	case 16: Uj = 0.484;
		break;
	case 32: Uj = 0.701;
		break;
	case 33: Uj = 1.5;
		break;
	case 34: Uj = 0.335;
		break;
	case 50: Uj = 0.199;
		break;
	case 51: Uj = 1.1;
		break;
	case 52: Uj =0.3 ;
		break;
	case 82: Uj = 0.1;
		break;
	case 83: Uj = 1.0;
		break;
	case 84: Uj = 0.3;
		break;
	default: Uj = 0.0;
	}

	switch (myAtoms[2].atomicNumber()){
	case 6: Uk = 2.119;
		break;
	case 7: Uk = 0.450;
		break;
	case 8: Uk = 0.018;
		break;
	case 14: Uk = 1.225;
		break;
	case 15: Uk = 2.400;
		break;
	case 16: Uk = 0.484;
		break;
	case 32: Uk = 0.701;
		break;
	case 33: Uk = 1.5;
		break;
	case 34: Uk = 0.335;
		break;
	case 50: Uk = 0.199;
		break;
	case 51: Uk = 1.1;
		break;
	case 52: Uk =0.3;
		break;
	case 82: Uk = 0.1;
		break;
	case 83: Uk = 1.0;
		break;
	case 84: Uk = 0.3;
		break;
	default: Uk = 0.0;
	}

	// to determine bond order between the central atoms
	double order = (myAtoms[1].getBond(myAtoms[2])).apporder();
	int an1 = myAtoms[1].atomicNumber();
	int an2 = myAtoms[2].atomicNumber();

	// if either central atom (ca) is from a B-group, or either is linear, vphi = 0
	if((an1 == 8) || (an1 == 16) || (an1 == 34) || (an1 == 52) || (an1 == 84)){
		bfromG6 = true;
	}
	if((an2 == 8) || (an2 == 16) || (an2 == 34) || (an2 == 52) || (an2 == 84)){
		cfromG6 = true;
	}

	// if either central atom (ca) is from a B-group, or either is linear, vphi = 0
	if((myAtoms[1].myGeom == 1) || (myAtoms[2].myGeom == 1) || (bfromG6) || (cfromG6)){
		vphi = 0;
		n = 0;
		phi0 = 0;
	}

	// if non main group, vphi = 0
	else if( ((an1>20) && (an1<30)) || ((an1>38) && (an1<49)) || ((an1>57) && (an1<80)) || ((an1>88) && (an1<113)) ){
		vphi = 0;
		n = 0;
		phi0 = 0;
	}

	else if( ((an2>20) && (an2<30)) || ((an2>38) && (an2<49)) || ((an2>57) && (an2<80)) || ((an2>88) && (an2<113)) ){
		vphi = 0;
		n = 0;
		phi0 = 0;
	}
	// Why were these 3 different statements?  They all do the same thing...

	// if one ca is sp3 and the other is sp2 with the fringe atom connected to sp2 also sp2
	else if( (order == 1) && (((myAtoms[1].myGeom == 3) && (myAtoms[2].myGeom == 2) && (myAtoms[3].myGeom == 2)) || ((myAtoms[2].myGeom == 3) && (myAtoms[1].myGeom == 2) && (myAtoms[0].myGeom == 2)) ) ){
		n = 3;
		phi0 = 180*convert;
		vphi = 2;
	}

	// if one ca is sp3 from group 6 and the other is sp2 not from group 6
	else if( (order == 1) && ( ((bfromG6) && (myAtoms[1].myGeom == 3) && (!cfromG6) && (myAtoms[2].myGeom == 2)) || ((cfromG6) && (myAtoms[2].myGeom == 3) && (!bfromG6) && (myAtoms[1].myGeom == 2)) ) ){
		// set Uj, Uk based on the row
		Uj = 0.1;
		if(an1 < 55) Uj = 0.2;
		if(an1 < 37) Uj = 0.7;
		if(an1 < 19) Uj = 1.25;
		if(an1 < 11) Uj = 2;

		Uk = 0.1;
		if(an2 < 55) Uk = 0.2;
		if(an2 < 37) Uk = 0.7;
		if(an2 < 19) Uk = 1.25;
		if(an2 < 11) Uk = 2;

		n = 2;
		phi0 = 90*convert;
		vphi = 5*Math.sqrt(Uj*Uk)*(1+4.18*Math.log(order));
	}

	// if both ca's are sp3 from group 6
	else if( (order == 1) && ((myAtoms[1].myGeom == 3) && (myAtoms[2].myGeom == 3) && (bfromG6) && (cfromG6)) ){
		// set Uj, Uk to 2 for oxygen, 6.8 otherwise
		if(an1 == 8) Uj = 2;
		else Uj = 6.8;
		if(an2 == 8) Uk = 2;
		else Uk = 6.8;

		vphi = Math.sqrt(Uj*Uk);
		n = 2;
		phi0 = 90*convert;
	}

	// if both ca's are sp2
	else if((myAtoms[1].myGeom == 2) && (myAtoms[2].myGeom == 2)){
		// get Uj, Uk based on the row
		Uj = 0.1;
		if(an1 < 55) Uj = 0.2;
		if(an1 < 37) Uj = 0.7;
		if(an1 < 19) Uj = 1.25;
		if(an1 < 11) Uj = 2;

		Uk = 0.1;
		if(an2 < 55) Uk = 0.2;
		if(an2 < 37) Uk = 0.7;
		if(an2 < 19) Uk = 1.25;
		if(an2 < 11) Uk = 2;
		n = 2;
		vphi = 5*Math.sqrt(Uj*Uk)*(1+4.18*Math.log(order));
		phi0 = 180*convert;	// Could also be 60
	}

	// if one ca is sp3 and the other is sp2
	else if( ((myAtoms[1].myGeom == 2) && (myAtoms[2].myGeom == 3)) || ((myAtoms[2].myGeom == 2) && (myAtoms[1].myGeom == 3)) )
	{
		n = 6;
		vphi = 1;
		phi0 = 0;
	}

	// if both ca's are sp3
	else if((myAtoms[1].myGeom == 3) && (myAtoms[2].myGeom == 3)){
		vphi = Math.sqrt(Uj*Uk);
		n = 3;
		phi0 = 180*convert;	// Could also be 60
	}

	// else vphi = 0 and n = 0
	else{
		vphi = 0;
		n = 0;
		phi0 = 0;
	}
	System.out.println("Vphi = "+vphi);
  }
/**
 * Insert the method's description here.
 * Creation date: (6/19/00 3:02:53 PM)
 */
  public int termLength()
	{
	  return 4;
	}
  public String name()
  {
	return "Torsion";
  }
}
