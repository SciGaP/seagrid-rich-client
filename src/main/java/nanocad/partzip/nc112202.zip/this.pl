#!/usr/ncsa/bin/perl

opendir(DIR,"tt") || die "Can't open: $!\n";

#@files = readdir(DIR);
$index = 0;
while( $myfile = readdir(DIR) )
  {
        if( $myfile =~ /\.pdb/ || $myfile =~ /\.mol2/ )
          {
                @files[$index] = $myfile;
                $index++;
          }
  }

closedir(DIR);

#foreach $file (@files)
for($i =0; $i <= $#files + 1; $i++)
  {  #print "$file\n"; 
     print" $files[$i]";
}
