package nanocad;

import java.awt.*;

public class nanocadMain
{
    public static void main(String args[])
    {
	Frame nano = new nanocadFrame();
	nano.setBounds(10, 10, 700, 600);
	nano.setVisible(true);
    }
}


