<?xml version="1.0" encoding="ISO-8859-1" standalone="no"?>

<helpset version="1.0">
   <title>GridChem Client Help</title>
   <maps>
      <homeID>d0e1</homeID>
      <mapref location="jhelpmap.jhm"/>
   </maps>
   <view>
      <name>TOC</name>
      <label>Table Of Contents</label>
      <type>oracle.help.navigator.tocNavigator.TOCNavigator</type>
      <data engine="oracle.help.engine.XMLTOCEngine">jhelptoc.xml</data>
   </view>
   <view>
      <name>Index</name>
      <label>Index</label>
      <type>oracle.help.navigator.keywordNavigator.KeywordNavigator</type>
      <data engine="oracle.help.engine.XMLIndexEngine">jhelpidx.xml</data>
   </view>
</helpset>
